from django import forms

class CoverForm(forms.Form):
    title = forms.CharField()
    top_text = forms.CharField()
    author = forms.CharField() 
    
	#docfile = forms.FileField(
	#	label ='Select a file',
	#	help_text ='max.42 megabytes'
	#	)
