from django.shortcuts import render
from blog.models import Category, Post
from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView
from django.http import HttpResponse
#from django.template import RequestContext
from django.urls import reverse
from django.template import loader


import numpy as np; np.random.seed(1234)
import pandas as pd
import numpy as np
import os
import re
import shutil
import urllib.request
from konlpy.tag import Okt
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import Embedding, Dense, LSTM
from tensorflow.keras.models import Sequential
from tensorflow.keras.models import load_model
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import csv
# Create your views here.
def index(req):
    post_latest = Post.objects.order_by("-createDate")[:6]
    print('메인 페이지')
    print(post_latest)
    context = {
        "post_latest": post_latest
    }

    return render(req, "index.html", context=context)

def test(req):	
    return render(req, 'test.html')

def page_1(req):
    return render(req, 'page_1.html')

def page_2(req):
    return render(req, 'page_2.html')


class PostDetailView(generic.DetailView):
    model = Post

class PostCreate(LoginRequiredMixin, CreateView):
    model = Post
    fields = ["title", "title_image", "content", "category"]


def main(req, pk):
	ntrain = 150000
	on_pre = [0,0] #원그래프 비율
	#tokenizer = Tokenizer()
	max_len = 30
	score_data= []
	test_dic={}
	top_key=[]
	top_value=[]

	data = pd.read_csv('C:/Users/dowon/test2/emotion/code/rating.txt', sep='\t', quoting=3)
	data = pd.DataFrame(np.random.permutation(data))
	trn, tst = data[:ntrain], data[ntrain:]

	header = 'id document label'.split()
	trn.to_csv('../1.txt', sep='\t', index=False, header=header)
	tst.to_csv('../2.txt', sep='\t', index=False, header=header)

	train_data = pd.read_table('1.txt')
	test_data = pd.read_table('2.txt')


	print('훈련용 리뷰 개수 :',len(train_data))
	print(train_data[:5])
	print('테스트용 리뷰 개수 :',len(test_data))
	print(test_data[:5])

	train_data.drop_duplicates(subset=['document'], inplace=True) # document 열에서 중복인 내용이 있다면 중복 제거
	print('총 샘플의 수 :',len(train_data))
	#train_data['label'].value_counts().plot(kind = 'bar') #레이블 값 분포 확인 차트
	print(train_data.groupby('label').size().reset_index(name = 'count'))
	print(train_data.isnull().values.any())
	print(train_data.isnull().sum())
	print(train_data.loc[train_data.document.isnull()])
	train_data = train_data.dropna(how = 'any') # Null 값이 존재하는 행 제거
	print(train_data.isnull().values.any()) # Null 값이 존재하는지 확인
	print(len(train_data))



	text = 'do!!! you expect... people~ to~ read~ the FAQ, etc. and actually accept hard~! atheism?@@'
	re.sub(r'[^a-zA-Z ]', '', text) #알파벳과 공백을 제외하고 모두 제거
	'do you expect people to read the FAQ etc and actually accept hard atheism'

	train_data['document'] = train_data['document'].str.replace("[^ㄱ-ㅎㅏ-ㅣ가-힣 ]","")
	# 한글과 공백을 제외하고 모두 제거
	print(train_data[:5])
	#전처리재검토
	train_data['document'].replace('', np.nan, inplace=True)
	print(train_data.isnull().sum())
	train_data = train_data.dropna(how = 'any')
	print(len(train_data))
	test_data.drop_duplicates(subset = ['document'], inplace=True) # document 열에서 중복인 내용이 있다면 중복 제거
	test_data['document'] = test_data['document'].str.replace("[^ㄱ-ㅎㅏ-ㅣ가-힣 ]","") # 정규 표현식 수행
	test_data['document'].replace('', np.nan, inplace=True) # 공백은 Null 값으로 변경
	test_data = test_data.dropna(how='any') # Null 값 제거
	print('전처리 후 테스트용 샘플의 개수 :',len(test_data))

	print('--------토큰화--------')
	#토큰화
	stopwords = []
	X_train = []
	with open('불용어사전.txt', 'r',encoding='utf-8') as f:
	    
	    for line in f:
	        stopwords.append(line.rstrip('\n'))
	okt = Okt()
	print(stopwords)

	for sentence in train_data['document']:
	    temp_X = []
	    temp_X = okt.morphs(sentence, stem=True) # 토큰화
	    temp_X = [word for word in temp_X if not word in stopwords] # 불용어 제거
	    X_train.append(temp_X)

	#with open('test1.txt', 'r',encoding='utf-8') as d:
	#   #reader = csv.writer(d)
	#	we=d.read()
	#	X_train.append(we.split('\t'))
	#print(test_ew)
	print(X_train)
	#정수 인코딩
	tokenizer = Tokenizer()
	tokenizer.fit_on_texts(X_train)
	#print(tokenizer.word_index)
	threshold = 3
	total_cnt = len(tokenizer.word_index) # 단어의 수
	rare_cnt = 0 # 등장 빈도수가 threshold보다 작은 단어의 개수를 카운트
	total_freq = 0 # 훈련 데이터의 전체 단어 빈도수 총 합
	rare_freq = 0 # 등장 빈도수가 threshold보다 작은 단어의 등장 빈도수의 총 합

	# 단어와 빈도수의 쌍(pair)을 key와 value로 받는다.
	for key, value in tokenizer.word_counts.items():
	    total_freq = total_freq + value

	    # 단어의 등장 빈도수가 threshold보다 작으면
	    if(value < threshold):
	        rare_cnt = rare_cnt + 1
	        rare_freq = rare_freq + value
	vocab_size = total_cnt - rare_cnt + 2

	tokenizer = Tokenizer(vocab_size, oov_token = 'OOV') 
	tokenizer.fit_on_texts(X_train)
	X_train = tokenizer.texts_to_sequences(X_train)

	max_len = 30
	print('완료')
	

	print(pk)
	object = Post.objects.filter(id=pk).first()
	sentences_result = []
	sentences_input = []
	sentences_results = [1,1,1]
	str = ''
	str = '{}'.format(object.title_image)

	#stopwords = []
	#with open('불용어사전.txt', 'r',encoding='utf-8') as f:
	#	for line in f:
	#		stopwords.append(line.rstrip('\n'))
	#okt = Okt()
	#print(stopwords)
	def score_histogram(score):
		print(score)
		if score>=90:
			score_count[0]+=1
		elif score>=80:
			score_count[1]+=1
		elif score>=70:
			score_count[2]+=1
		elif score>=60:
			score_count[3]+=1
		elif score>=50:
			score_count[4]+=1
		else:
			print("올바른문장")

	loaded_model = load_model('best_model.h5')
	def sentiment_predict(new_sentence):

		new_sentence = okt.morphs(new_sentence, stem=True) # 토큰화
		new_sentence = [word for word in new_sentence if not word in stopwords] # 불용어 제거
		encoded = tokenizer.texts_to_sequences([new_sentence]) # 정수 인코딩
		pad_new = pad_sequences(encoded, maxlen = max_len) # 패딩
		score = float(loaded_model.predict(pad_new)) # 예측
		if(score > 0.5):
			print("{:.2f}% 확률로 욕설 문장입니다.\n".format(score * 100))
			score_data.append(score*100)
			word="욕설\n"
			on_pre[0] +=1
			return word
		else:
			print("{:.2f}% 확률로 올바른 문장입니다.\n".format((1 - score) * 100))
			word="문제없음\n"
			on_pre[1]+=1
			score_data.append(score*100)
			
			return word
	
	labels = ['욕설 문장','바른 문장'] #원그래프 데이터
	num =0
	score_count=[0,0,0,0,0]
	with open('C:/Users/dowon/test2/emotion/code/mywebsite/media/'+str, 'r',encoding='utf-8') as f:
		sentences_result = []
		sentences_input = []
		sentences_results = [1,1,1]
		for sentence_input in f:
			sentences_input.append(sentence_input)
			print(sentence_input)
			sentences_result.append(sentence_input.rstrip('\n')+""+sentiment_predict(sentence_input.rstrip('\n')))
			test_dic[sentence_input]=score_data[num]
			
			num+=1

		for score in score_data:
			score_histogram(score)
		
		
	
	for key,value in sorted(test_dic.items(),key=lambda x: x[1],reverse=True):
		top_key.append(key)
		top_value.append(value)

	print(score_data)
	print(score_count)
	print(sentences_result)
	
	context = {
		"sentences_result":sentences_result,
		"sentences_results":sentences_results,
		"sentences_input": sentences_input,
		"labels": labels,
		"data": on_pre,
		"data1":score_count,
		"top_key": top_key,
		"top_value": top_value

	}
	return render(req,"blog/test.html",context)

def below_threshold_len(max_len, nested_list):
  cnt = 0
  for s in nested_list:
    if(len(s) <= max_len):
        cnt = cnt + 1
  print('전체 샘플 중 길이가 %s 이하인 샘플의 비율: %s'%(max_len, (cnt / len(nested_list))*100))
