from django.urls import path
from blog import views

urlpatterns = [
    path("", views.index, name="index"),
    path("post/page_1", views.page_1, name="page1"),
    path("post/page_2", views.page_2, name="page2"),
    path("post/test/", views.test, name="test"),
    path("post/<int:pk>", views.PostDetailView.as_view(), name="post"),
    path("post/create", views.PostCreate.as_view(), name="post_create"),
    path("post/main/<int:pk>", views.main, name="main"),
]

